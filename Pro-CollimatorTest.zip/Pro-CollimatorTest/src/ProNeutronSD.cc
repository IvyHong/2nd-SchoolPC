#include "ProNeutronSD.hh"
#include "G4HCofThisEvent.hh"
#include "G4Step.hh"
#include "G4ThreeVector.hh"
#include "G4SDManager.hh"
#include "G4ios.hh"

#include "G4Material.hh"
#include "G4TouchableHandle.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ProNeutronSD::ProNeutronSD(const G4String &name)
:G4VSensitiveDetector(name),
  nHitsCollection(0)
{
    collectionName.insert("NEUTRONHitsCollection");
    nHCID = -1;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ProNeutronSD::~ProNeutronSD(){ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ProNeutronSD::Initialize(G4HCofThisEvent* HCE)
{
  nHitsCollection = new ProNeutronHitsCollection
                          (SensitiveDetectorName,collectionName[0]);

  if(nHCID<0)
  { nHCID = G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]); }
  HCE->AddHitsCollection( nHCID, nHitsCollection );
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4bool ProNeutronSD::ProcessHits(G4Step* aStep,G4TouchableHistory*)
{
  // Get Material

  G4String thisVolume = aStep->GetPreStepPoint()->GetTouchableHandle()->GetVolume()->GetName();
  G4String particleName = aStep->GetTrack()->GetDefinition()->GetParticleName();


  if (thisVolume != "NeutronSD") return false;
  if (particleName != "neutron" ) return false;
  G4StepPoint* preStepPoint = aStep->GetPreStepPoint();
   G4TouchableHistory* theTouchable
     = (G4TouchableHistory*)(preStepPoint->GetTouchable());
   G4int copyNo = theTouchable->GetVolume()->GetCopyNo();
  if(particleName == "neutron"&& thisVolume=="NeutronSD") {/*aStep->GetTrack()->SetTrackStatus(fStopAndKill);*/

  // check if this finger already has a hit
  G4int ix = -1;
  for(G4int i=0;i<nHitsCollection->entries();i++)
  {
    if((*nHitsCollection)[i]->GetID()==copyNo)
    {
      ix = i;
      break;
    }
  }

  ProNeutronHit* neutronNewHit = new ProNeutronHit(copyNo);

  neutronNewHit->SetPosition (aStep->GetPostStepPoint()->GetPosition());  //global coordinates
  neutronNewHit->SetMomentum (aStep->GetTrack()->GetMomentum());
  nHitsCollection->insert  ( neutronNewHit );}

  //neutronNewHit->Print();
  //neutronNewHit->Draw();

//  G4cout << "*******************************" << G4endl;
//  G4cout << "          neutron HIT          " << G4endl;
//  G4cout << "  Volume:                      " << thisVolume << G4endl;
//  G4cout << "  POSITION (m) :              "
//         << aStep->GetPostStepPoint()->GetPosition().x()/m << " " << aStep->GetPostStepPoint()->GetPosition().y()/m
//         << " " << aStep->GetPostStepPoint()->GetPosition().z()/m << G4endl;
//  G4cout << "  Momentum (MeV):              "
//         << aStep->GetTrack()->GetMomentum()/MeV << G4endl;
//  G4cout << "*******************************" << G4endl;

  return true;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ProNeutronSD::EndOfEvent(G4HCofThisEvent*/* HCE*/)
{
//  static G4int HCID = -1;
//  if(HCID<0)
//    {
//      HCID = G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]);
//    }
//  HCE->AddHitsCollection(HCID,nHitsCollection);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
