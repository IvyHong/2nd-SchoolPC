#include "ProDetectorConstruction.hh"
#include "TSLCollimator.hh"
//#include "G4PVParameterised.hh"

#include "globals.hh"
#include "G4RunManager.hh"

#include "G4Box.hh"
#include "G4Tubs.hh"
//#include "G4Sphere.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4RotationMatrix.hh"
#include "G4SubtractionSolid.hh"
#include "G4Transform3D.hh"
#include "G4ThreeVector.hh"

#include "G4Material.hh"
#include "G4Element.hh"
#include "G4MaterialTable.hh"
#include "G4NistManager.hh"

// Sensitivedetector
#include "G4SDManager.hh"
#include "ProNeutronSD.hh"
#include "ProGammaSD.hh"
#include "CollimatorSD.hh"

// visualisation
#include "G4VisAttributes.hh"
#include "G4Colour.hh"

#include "G4Region.hh"
#include "G4RegionStore.hh"

ProDetectorConstruction::ProDetectorConstruction()
    : CollimatorGeometry(0),
      WorldLog(0),TargetLog(0),neutronSDLog(0),gammaSDLog(0),collimatorSDLog(0),
      WorldPhy(0),fCheckOverlap(true),
      Air(0),TargetMat(0),DefaultMat(0),CollimatorMat(0)
{
    fWorldLength = 5048*mm;
    collimatorW  = 1200*mm;
    collimatorL  = 1000*mm;
    collimatorH  = 2402*mm;
    apertureDia  = 102 *mm;
    Distance     = 867*mm;
    Detthick     = 1*mm;
    NbOfDetector = 3;
    collimatorYMov = 296*mm;
}

ProDetectorConstruction::~ProDetectorConstruction()
{}



G4VPhysicalVolume* ProDetectorConstruction::Construct()
{
     DefineMaterials();
     return SetupGeometry();
}


void ProDetectorConstruction::DefineMaterials()
{
//---------All material being used in this project ------//
    //  use G4-NIST materials data base
  G4NistManager* MAN=G4NistManager::Instance();

    Air=MAN->FindOrBuildMaterial("G4_AIR");
    TargetMat=MAN->FindOrBuildMaterial("G4_W");
    DefaultMat=MAN->FindOrBuildMaterial("G4_Galactic");

    // collimator material Steel/iron, not in NIST
    G4Element* C =MAN->FindOrBuildElement("C");
    G4Element* Si=MAN->FindOrBuildElement("Si");
    G4Element* Cr=MAN->FindOrBuildElement("Cr");
    G4Element* Mn=MAN->FindOrBuildElement("Mn");
    G4Element* Fe=MAN->FindOrBuildElement("Fe");
    G4Element* Ni=MAN->FindOrBuildElement("Ni");

    G4double      density;
    G4int     ncomponents;
    G4double fractionmass;
    /// @ CollimatorMat : StainlessSteel
    CollimatorMat=new G4Material("StainlessSteel",density=8.06*g/cm3,ncomponents=6);
    CollimatorMat->AddElement(C,fractionmass=0.001);
    CollimatorMat->AddElement(Si,fractionmass=0.007);
    CollimatorMat->AddElement(Cr,fractionmass=0.18);
    CollimatorMat->AddElement(Mn,fractionmass=0.01);
    CollimatorMat->AddElement(Fe,fractionmass=0.712);
    CollimatorMat->AddElement(Ni,fractionmass=0.09);

  //  Print out material so that we need to find that material G4_AIR
  G4cout<< G4endl
        << "******* World material : "  << DefaultMat << "\n"
        <<"******** Target material : " << TargetMat << "\n"
        << "******* Sensitive detector material : " << DefaultMat << "\n"
        << "******* Collimator material :" << CollimatorMat << G4endl;
  G4cout<<*(G4Material::GetMaterialTable())<<G4endl;
}

G4VPhysicalVolume* ProDetectorConstruction::SetupGeometry()
{
    if(!DefaultMat||!TargetMat){
             G4cerr<< "Cannot retrieve materials already defined. " << G4endl;
             G4cerr<< "Exiting application " << G4endl;
             exit(1);
    }

    //---------Geometry being used in this project ----------//
    // World, box,full length= 5.048 meter
    //------------------------------world volume (shape: box)
      G4Box* WorldSolid = new G4Box("World_solid",     //Name
                                     fWorldLength/2,    //half length
                                     fWorldLength/2,
                                     fWorldLength/2);

      WorldLog = new G4LogicalVolume(WorldSolid,         // Solid
                                     DefaultMat,         // filled material
                                     "World");

      WorldPhy = new G4PVPlacement  (0,                    // Rotation matrix
                                     G4ThreeVector(),      // Position (0,0,0)
                                     WorldLog,             // Logical volume
                                     "World",              // Name
                                     0,                    // Mother volume
                                     false,                // unused boolean
                                     0,                    // copy number
                                     fCheckOverlap);       // checking overlap


  //-------------Target cylindar--------------------------------------//
      // Target tube, diameter 5*cm,height 24mm
      // Target Centre position is moved in -z: (0,0,-144mm-12mm)
      const G4double TargetInR=0.*cm;
      const G4double TargetOutR=2.5*cm;
      const G4double TargetHeight=2.4*cm;
      G4ThreeVector  TargetPos = G4ThreeVector(0.,0.,-TargetHeight/2);

      G4Tubs* Target_tubs = new G4Tubs ("TargetSolid",          //Name
                                      TargetInR,                //Inner radius
                                      TargetOutR,               //Outer radius
                                      TargetHeight/2,           // Half length in z
                                      0.*deg,                   // Starting phi angle
                                      360.*deg);                // Segment angle

      TargetLog = new G4LogicalVolume (Target_tubs,
                                       DefaultMat,
                                       "Target");
      new G4PVPlacement (0,
                        TargetPos,
                        TargetLog,
                        "Target",
                        WorldLog,
                        false,
                        0,
                        fCheckOverlap);

//---- Collimator wtih a hole inside--------------------------//
// Collimator, rectangular solid,full length z= 1 m, x=1.2 m, y=2.402 m;
// Standard hole or aperture, diamater =10.2cm, length =1 m, Distance =867mm;
// Collimator's position is moved in +z (World) : 867mm + TargetHeight/2 + CollimatorZ/2; in -y : 296mm
// The hole's position is moved to +y :   296mm
// G4double apertureYMov = 296*mm;
      G4double CollimatorZMov = collimatorL/2+Distance;
      G4ThreeVector CollimatorPos (0,-collimatorYMov,CollimatorZMov);
      G4RotationMatrix* collimatorRot =0;
    //-------------collimator volume (shape: box)
      CollimatorGeometry = new TSLCollimator(apertureDia,
                                             collimatorW,
                                             collimatorL,
                                             collimatorH,
                                             CollimatorMat,
                                             WorldPhy,
                                             CollimatorPos,
                                             collimatorRot);
// *************************************************************************************************
  // print parameters
  //
      G4cout  <<	"\n******************************************************************"
              <<	"\n--->	The	Target	Material :	"  << TargetMat->GetName()	<<	'\n'
              <<	"\n--->	Collimator	Material : 	"  << CollimatorMat->GetName()	<<  '\n'
              <<	"	The	World	space	is	filled	with	"<<	DefaultMat->GetName()	<<	G4endl;

// *************************************************************************************************

// The Sensitive detectors are not sphere anymore, since more sensitive detectors are going to be added
// Chane the sensitive detectors shape to box
//***********************************************************************
// Sensitive Detector Geometry                                          *
//***********************************************************************
//  Sensitive detector  (shape: box), rectangular solid,full length z= 1 mm, x=1.2 m, y=2.402 m;
//  Detector contains two detectors: one to measure neutron, the other to measure gamma;

////
//// Sensitive detector      (shape: box)
////

/// Collimator Sensitive Detector located in the front of collimator and behind of collimator
///
         G4double InitialZPos = 0.;
         G4Box* miniSDsol = new G4Box("CollimatorSDsolid", //Name
                                      collimatorW/2,     //Half length
                                      collimatorH/2,
                                      Detthick/2);
         collimatorSDLog = new G4LogicalVolume(miniSDsol,        //its solid
                                               DefaultMat,       //its material
                                              "CollimatorSD");   //its name
         for(G4int i=0;i<2;i++)
         {
           InitialZPos = Distance - 1.5*Detthick + (collimatorL + 2*Detthick)*i;
           new G4PVPlacement(0,
               G4ThreeVector(0,-collimatorYMov,InitialZPos),
                              collimatorSDLog,
                             "CollimatorSD",
                              WorldLog,
                              false,
                              i,
                              fCheckOverlap);
         }


/// **********************************************************************************************

//   G4double NeuPos = 0.;
//   G4double GamPos = 0.;
//   G4Box* miniSDsol = new G4Box("NeutronSD_solid", //Name
//                                collimatorW/2,      //half length
//                                collimatorH/2,
//                                Detthick/2);
//   neutronSDLog = new G4LogicalVolume(miniSDsol,        //its solid
//                                      DefaultMat,              //its material
//                                      "NeutronSD");     //its name
//   gammaSDLog = new G4LogicalVolume(miniSDsol,        //its solid
//                                    DefaultMat,              //its material
//                                    "GammaSD");       //its name

//            for(G4int i=0;i<NbOfDetector;i++)
//            {
//                if(i<2)
//                {
//                    NeuPos = Distance - 1.5*Detthick + (collimatorL + 2*Detthick)*i;
//                    GamPos = Distance - 0.5*Detthick + (collimatorL + 2*Detthick)*i;
//                }
//                else
//                {
//                    NeuPos = 2500*mm - 1.5*Detthick;
//                    GamPos = 2500*mm - 0.5*Detthick;
//                }


//               new G4PVPlacement(0,
//                   G4ThreeVector(0,CollimatorYMov,NeuPos),
//                                neutronSDLog,
//                               "NeutronSD",
//                                WorldLog,
//                                false,
//                                i,
//                                fCheckOverlap);
//              new G4PVPlacement(0,
//                  G4ThreeVector(0,-CollimatorYMov,GamPos),
//                                 gammaSDLog,
//                                "GammaSD",
//                                 WorldLog,
//                                 false,
//                                 i,
//                                 fCheckOverlap);
//            }


      // Create sensitive detectors: 1mm hemispherical shells at 2.5m.
      //--Neutron Detector
//      G4double innerRadius = 2.499*m;
//      G4double outerRadius = 2.500*m;
//      G4double azStart = 0.;
//      G4double azDelta = 360.*deg;
//      G4double elStart = 0.;
//      G4double elDelta = 90.*deg;
//      /// @todo Check - should this be a G4VSolid* or a G4Sphere* ?
//      G4VSolid*	nSphereSolid= new G4Sphere("NeutronSphere",
//                                             innerRadius,outerRadius,
//                                             azStart,azDelta,
//                                             elStart,elDelta);
//      neutronSDLog	=	new	G4LogicalVolume(nSphereSolid,DefaultMat,"NeutronSphere");
//      /// @todo Check: is this bare new correct?
//      new G4PVPlacement(0,G4ThreeVector(0,0,0),neutronSDLog,"NeutronSphere",
//                        WorldLog,false,0,fCheckOverlap);
//      //--Gamma Detector
//      innerRadius = 2.500*m;
//      outerRadius = 2.501*m;
//      /// @todo Check - should this be a G4VSolid* or a G4Sphere* ?
//      G4VSolid* gSphereSolid = new G4Sphere("GammaSphere",
//                                            innerRadius,outerRadius,
//                                            azStart,azDelta,
//                                            elStart,elDelta);
//      gammaSDLog = new G4LogicalVolume(gSphereSolid,DefaultMat,"GammaSphere");
//      /// @todo Check: is this bare new correct?
//      new G4PVPlacement(0,G4ThreeVector(0,0,0),gammaSDLog,"GammaSphere",
//                        WorldLog,false,0,fCheckOverlap);

//**************************************** ANITA End ********************************************//

//**************************************** LANSCE Model *****************************************//
//  //---------Geometry being used in this project ----------//
//  // World, box,full length=41.1 meter
//     G4double fWorldLength=41*m;
//  //------------------------------world volume (shape: box)
//    G4Box* WorldSolid = new G4Box("World_solid",     //Name
//                                   fWorldLength/2,    //half length
//                                   fWorldLength/2,
//                                   fWorldLength/2);

//    WorldLog = new G4LogicalVolume(WorldSolid,         // Solid
//                                   Air,               // filled material
//                                   "World_log");

//    WorldPhy = new G4PVPlacement  (0,                    // Rotation matrix
//                                   G4ThreeVector(),      // Position (0,0,0)
//                                   WorldLog,             // Logical volume
//                                   "World_phys",         // Name
//                                   0,                    // Mother volume
//                                   false,                // unused boolean
//                                   0,                    // copy number
//                                   fCheckOverlap);      // checking overlaps


////-------------Target cylindar--------------------------------------//
//    // target tube, diameter 3*cm,height 7cm
//    G4double TargetInR=0.*cm;
//    G4double TargetOutR=1.5*cm;
//    G4double TargetHeight=7*cm;

//    G4Tubs* Target_tubs = new G4Tubs ("TargetSolid",         //Name
//                                    TargetInR,                //Inner radius
//                                    TargetOutR,               //Outer radius
//                                    TargetHeight/2,           // Half length in z
//                                    0.*deg,                   // Starting phi angle
//                                    360.*deg);                // Segment angle

//    TargetLog = new G4LogicalVolume (Target_tubs,
//                                     TargetMat,
//                                     "TargetLog");
//    new G4PVPlacement (0,
//                      G4ThreeVector(0.,0.,0.),
//                      TargetLog,
//                      "TargetPhy",
//                      WorldLog,
//                      false,
//                      0,
//                      fCheckOverlap);
//// print parameters
////
//    //	print	parameters
//    G4cout	<<	"\n------------------------------------------------------------"
//            <<	"\n--->	The	Target	is	consist	of	"	<<	TargetMat->GetName()	<<	'\n'
//            <<	"	The	World	space	is	filled	with	"<<	Air->GetName()	<<	G4endl;

////--------------------------------------------------------------------------------------

//    // Create sensitive detectors: 1mm hemispherical shells at 20m.
//    //--Neutron Detector
//    G4double innerRadius = 19.999*m;
//    G4double outerRadius = 20.0*m;
//    G4double azStart = 0.;
//    G4double azDelta = 360.*deg;
//    G4double elStart = 0.;
//    G4double elDelta = 90.*deg;
//    /// @todo Check - should this be a G4VSolid* or a G4Sphere* ?
//    G4VSolid*	nSphereSolid= new G4Sphere("NeutronSphere",
//                                           innerRadius,outerRadius,
//                                           azStart,azDelta,
//                                           elStart,elDelta);
//    neutronSDLog	=	new	G4LogicalVolume(nSphereSolid,DefaultMat,"NeutronSphere");
//    /// @todo Check: is this bare new correct?
//    new G4PVPlacement(0,G4ThreeVector(0,0,0),neutronSDLog,"NeutronSphere",
//                      WorldLog,false,0,fCheckOverlap);
//    //--Gamma Detector
//    innerRadius = 20.0*m;
//    outerRadius = 20.001*m;
//    /// @todo Check - should this be a G4VSolid* or a G4Sphere* ?
//    G4VSolid* gSphereSolid = new G4Sphere("GammaSphere",
//                                          innerRadius,outerRadius,
//                                          azStart,azDelta,
//                                          elStart,elDelta);
//    gammaSDLog = new G4LogicalVolume(gSphereSolid,DefaultMat,"GammaSphere");
//    /// @todo Check: is this bare new correct?
//    new G4PVPlacement(0,G4ThreeVector(0,0,0),gammaSDLog,"GammaSphere",
//                      WorldLog,false,0,fCheckOverlap);
//********************************************* LANSCE end *******************************************//


    // Visualisation attributes
    // Invisible world volume
    WorldLog->SetVisAttributes(G4VisAttributes::Invisible);

//  // Mother sphere volume White (1.0,1.0,1.0) 0.2 means how much transparancy (0-1.0)
//    G4VisAttributes* neutronAttributes = new G4VisAttributes(G4Color(1.0,1.0,1.0));
//    neutronAttributes->SetVisibility(true);
//    neutronSDLog->SetVisAttributes(neutronAttributes);

////  // Ring scorer volumes Gray with transparancy
//    G4VisAttributes* gammaAttributes = new G4VisAttributes(G4Color(0.,1.,0.));
//    gammaAttributes->SetVisibility(true);
//    gammaSDLog->SetVisAttributes(gammaAttributes);

  // target volumes Blue with transparancy
    G4VisAttributes* targetAttributes = new G4VisAttributes(G4Color(0.0,0.0,1.0));
    targetAttributes->SetVisibility(true);
    TargetLog->SetVisAttributes(targetAttributes);

  // Collimator volume Gray with transparancy
    G4VisAttributes* collimatorAttributes = new G4VisAttributes(G4Color(0.5,0.5,0.5));
    collimatorAttributes->SetForceSolid(true);
    if(CollimatorGeometry)
    {
        CollimatorGeometry->GetPhysicalVolume()->GetLogicalVolume()->SetVisAttributes(collimatorAttributes);
    }

    // Collimator detectors volumes white with transparancy
      G4VisAttributes* detectorAttributes = new G4VisAttributes(G4Color(1.0,1.0,1.0));
      detectorAttributes->SetVisibility(true);
      collimatorSDLog->SetVisAttributes(detectorAttributes);

//***************************************************************************
// Sensitive detector
//***************************************************************************
//    G4VSensitiveDetector* neutrondetector;
//    G4VSensitiveDetector* gammadetector;

//// Collimator Sensitive Detectors
    G4VSensitiveDetector* collimatordetector;


    G4SDManager* SDman = G4SDManager::GetSDMpointer();
    G4String SDname;
//// **************************************************************
//    // Neutron detector*******************************************
//    neutrondetector = new ProNeutronSD (SDname="NeutronSDet");
//    // Get pointer to detector manager
//    SDman->AddNewDetector(neutrondetector);
//    // Attach detector to volume defining neutronSDLog
//    neutronSDLog->SetSensitiveDetector(neutrondetector);

//    // Gamma detector*******************************************
//    gammadetector = new ProGammaSD (SDname="GammaSDet");
//    // Get pointer to detector manager
//    SDman->AddNewDetector(gammadetector);
//    // Attach detector to volume defining neutronSDLog
//    gammaSDLog->SetSensitiveDetector(gammadetector);

     // Collimator detector*******************************************
      collimatordetector = new CollimatorSD (SDname="CollimatorSDet");
     // Get pointer to detector manager
      SDman->AddNewDetector(collimatordetector);
     // Attach detector to volume defining neutronSDLog
      collimatorSDLog->SetSensitiveDetector(collimatordetector);



    return WorldPhy;
}



