#include	"ProAnalysis.hh"
#include	"G4UnitsTable.hh"
#include	"G4SystemOfUnits.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ProAnalysis::ProAnalysis()
{
        fileName[0]	=	"Output";
        factoryOn	=	false;
        //	ntuple
        for	(G4int	k=0;	k<MaxNtCol;	k++)
        {
                fNtColId[k]	=	0;
        }
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
ProAnalysis::~ProAnalysis()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
void	ProAnalysis::book()
{
        //	Create	or	get	analysis	manager
        //	The	choice	of	analysis	technology	is	done	via	selection	of	a	namespace
        //	in	ProAnalysis.hh
        G4AnalysisManager*	analysisManager	=	G4AnalysisManager::Instance();
        analysisManager->SetVerboseLevel(2);
        G4String	extension	=	analysisManager->GetFileType();
        fileName[1]	=	fileName[0]	+	"."	+	extension;
        //	Create	directories
        analysisManager->SetNtupleDirectoryName("ntuple");
        //	Open	an	output	file
        //
        G4bool	fileOpen	=	analysisManager->OpenFile(fileName[0]);
        if	(!fileOpen)	{
                G4cout	<<	"\n--->	ProAnalysis::book():	cannot	open	"	<<	fileName[1]
                         <<	G4endl;
                return;
        }

        analysisManager->CreateNtuple("Ntuple",	"position & Momentum	: ");
        fNtColId[0]	=	analysisManager->CreateNtupleDColumn("gPosition X ");
        fNtColId[1]	=	analysisManager->CreateNtupleDColumn("gPosition Y");
        fNtColId[2]	=	analysisManager->CreateNtupleDColumn("gPosition Z");
        fNtColId[3]	=	analysisManager->CreateNtupleDColumn("gMomentum X");
        fNtColId[4]	=	analysisManager->CreateNtupleDColumn("gMomentum Y");
        fNtColId[5]	=	analysisManager->CreateNtupleDColumn("gMomentum Z");
        fNtColId[6]	=	analysisManager->CreateNtupleDColumn("nPosition X ");
        fNtColId[7]	=	analysisManager->CreateNtupleDColumn("nPosition Y");
        fNtColId[8]	=	analysisManager->CreateNtupleDColumn("nPosition Z");
        fNtColId[9]	=	analysisManager->CreateNtupleDColumn("nMomentum X");
        fNtColId[10]=	analysisManager->CreateNtupleDColumn("nMomentum Y");
        fNtColId[11]=	analysisManager->CreateNtupleDColumn("nMomentum Z");

        analysisManager->FinishNtuple();
        factoryOn	=	true;
        G4cout	<<	"\n---->	Histogram	Tree	is	opened	in	"	<<	fileName[1]	<<	G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void	ProAnalysis::save()
{
        if	(factoryOn)
        {
                G4AnalysisManager*	analysisManager	=	G4AnalysisManager::Instance();
                analysisManager->Write();
                analysisManager->CloseFile();
                G4cout	<<	"\n---->	Histogram	Tree	is	saved	in	"	<<	fileName[1]	<<	G4endl;
                delete	G4AnalysisManager::Instance();
                factoryOn	=	false;
        }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void	ProAnalysis::gFillNtuple(G4double Pos_X, G4double Pos_Y, G4double Pos_Z,
                             G4double Mom_X, G4double Mom_Y, G4double Mom_Z)
{
        G4AnalysisManager*	analysisManager	=	G4AnalysisManager::Instance();
        analysisManager->FillNtupleDColumn(fNtColId[0],	Pos_X);
        analysisManager->FillNtupleDColumn(fNtColId[1],	Pos_Y);
        analysisManager->FillNtupleDColumn(fNtColId[2],	Pos_Z);
        analysisManager->FillNtupleDColumn(fNtColId[3],	Mom_X);
        analysisManager->FillNtupleDColumn(fNtColId[4],	Mom_Y);
        analysisManager->FillNtupleDColumn(fNtColId[5],	Mom_Z);
        analysisManager->AddNtupleRow();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void	ProAnalysis::nFillNtuple(G4double Pos_X, G4double Pos_Y, G4double Pos_Z,
                             G4double Mom_X, G4double Mom_Y, G4double Mom_Z)
{
        G4AnalysisManager*	analysisManager	=	G4AnalysisManager::Instance();
        analysisManager->FillNtupleDColumn(fNtColId[6],	Pos_X);
        analysisManager->FillNtupleDColumn(fNtColId[7],	Pos_Y);
        analysisManager->FillNtupleDColumn(fNtColId[8],	Pos_Z);
        analysisManager->FillNtupleDColumn(fNtColId[9],	Mom_X);
        analysisManager->FillNtupleDColumn(fNtColId[10],	Mom_Y);
        analysisManager->FillNtupleDColumn(fNtColId[11],	Mom_Z);
        analysisManager->AddNtupleRow();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void	ProAnalysis::PrintStatistic()
{
        if(factoryOn)
        {
            G4cout	<<	"\n	---->	print	Position  &&  Momentum  information	\n"	<<	G4endl;
        }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

