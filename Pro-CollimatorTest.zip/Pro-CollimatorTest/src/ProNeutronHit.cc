#include "ProNeutronHit.hh"
#include "G4UnitsTable.hh"
#include "G4VVisManager.hh"
#include "G4Circle.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"

G4Allocator<ProNeutronHit> ProNeutronHitAllocator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ProNeutronHit::ProNeutronHit(G4int i)
{
    nID = i;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ProNeutronHit::~ProNeutronHit() {}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ProNeutronHit::ProNeutronHit(const ProNeutronHit& right)
  : G4VHit()
{
  nID             = right.nID;
  nPosition       = right.nPosition;
  nMomentum       = right.nMomentum;

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

const ProNeutronHit& ProNeutronHit::operator=(const ProNeutronHit& right)
{
    nID             = right.nID;
    nPosition       = right.nPosition;
    nMomentum       = right.nMomentum;
    return *this;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4int ProNeutronHit::operator==(const ProNeutronHit& right) const
{
  return (this==&right) ? 1 : 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ProNeutronHit::Draw()
{
  G4VVisManager* pVVisManager = G4VVisManager::GetConcreteInstance();
  if(pVVisManager)
  {
    G4Circle circle(nPosition);
    circle.SetScreenSize(2.);
    circle.SetFillStyle(G4Circle::filled);
    G4Colour colour(1.,0.,0.);
    G4VisAttributes attribs(colour);
    circle.SetVisAttributes(attribs);
    pVVisManager->Draw(circle);
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ProNeutronHit::Print()
{
    G4cout << "****************************************************"
           << "\n  Neutron Detector: " << nID << '\n'
           << "  position: " << G4BestUnit(nPosition,"Length") << '\n'
           << "  Momentum: " << G4BestUnit(nMomentum,"Energy") << '\n'
           << "***************************************************** " <<  G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

