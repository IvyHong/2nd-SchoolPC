#include	"ProEventAction.hh"
#include	"ProRunAction.hh"
#include	"ProAnalysis.hh"
#include	"ProGammaHit.hh"
#include    "CollimatorDetectorHit.hh"
#include    "ProNeutronHit.hh"

#include	"G4Event.hh"
#include	"G4RunManager.hh"
#include	"G4ios.hh"
#include	"G4UnitsTable.hh"
#include	"Randomize.hh"
#include	<iomanip>

#include	"G4HCofThisEvent.hh"
#include	"G4SDManager.hh"


//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
ProEventAction::ProEventAction(ProRunAction* runact, ProAnalysis* anl)
    : fRunAct(runact),
      fAnalysis(anl),
//      gHitsCollID(-1),
//      nHitsCollID(-1),
      pHitsCollID(-1)
{
    fPrintModulo = 100;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ProEventAction::~ProEventAction()
{}

void ProEventAction::PrintEventStatistics(G4ThreeVector Pos, G4ThreeVector Mom) const
{
  // print event statistics
  G4cout
     << "  Position : "
     << std::setw(7) << G4BestUnit(Pos, "Length")
     << "  Momentum: "
     << std::setw(7) << G4BestUnit(Mom, "Energy")
     << G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
void	ProEventAction::BeginOfEventAction(const	G4Event*	evt)
{
    G4int   evtNb	=	evt->GetEventID();
    if	(evtNb%fPrintModulo	==	0)
    G4cout	<<	"\n------> Begin of Event:	"	<<	evtNb	<<	G4endl;

    G4SDManager	*	SDman	=	G4SDManager::GetSDMpointer();
//    if(-1==gHitsCollID)	{
//       gHitsCollID	=	SDman->GetCollectionID("GAMMAHitsCollection");
//                }
//    if(-1==nHitsCollID)	{
//       nHitsCollID	=	SDman->GetCollectionID("NEUTRONHitsCollection");
//                }
    if(-1==pHitsCollID)	{
       pHitsCollID	=	SDman->GetCollectionID("NEUTRONHitsCollection");
                }
}


//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
void    ProEventAction::EndOfEventAction(const	G4Event* evt)
{
    G4HCofThisEvent*	HCE	=	evt->GetHCofThisEvent();
//    ProGammaHitsCollection*	gHitsColl	  =	0;
//    ProNeutronHitsCollection*  nHitsColl  = 0;
    CollimatorDetectorHitsCollection* pHitsColl = 0;

    // Output code of gamma hits
//    if(HCE)
//    {
//        if(gHitsCollID	!=	-1)	gHitsColl=(ProGammaHitsCollection*)(HCE->GetHC(gHitsCollID));
//    }

//    G4int	gammaHits	=0	;
//    // Store gamma
//    if(gHitsColl)
//    {
//        gammaHits	=	gHitsColl->entries();

//        if	(gammaHits	>	0){

////            G4cout	<<	"Gamma	Hit	#"	<<	"	"	<<	"   Position x,y,z	  "	<<		"	"
////                     <<	"   Momentum (x,y,z)	"<< G4endl	;
//        }
//        for(G4int	iHit=0;	iHit<gammaHits;	iHit++){
//             G4ThreeVector gHitPosition= (*gHitsColl)[iHit]->GetPosition();
//             G4ThreeVector gHitMomentum= (*gHitsColl)[iHit]->GetMomentum();
//             // PrintEventStatistics(gHitPosition,gHitMomentum);
//             // Fill ntuple
//            fAnalysis->gFillNtuple(gHitPosition.x(), gHitPosition.y(), gHitPosition.z(),
//                                   gHitMomentum.x(), gHitMomentum.y(), gHitMomentum.z());
//        }
//    }


//    // Output code of neutron hits
//    if(HCE){
//        if(nHitsCollID	!=	-1)	nHitsColl=(ProNeutronHitsCollection*)(HCE->GetHC(nHitsCollID));
//    }

//    G4int	neutronHits	=0	;
//    // Store neutrons
//    if(nHitsColl)
//    {
//        neutronHits	=	nHitsColl->entries();
//        G4cout << "NeutronDetectors have " << neutronHits << " hits." << G4endl;

//        for(G4int	iHit=0;	iHit<neutronHits; iHit++){
//             ProNeutronHit* aHit = (*nHitsColl)[iHit];
////             aHit->Print();
//             G4ThreeVector nHitPosition= (*nHitsColl)[iHit]->GetPosition();
//             G4ThreeVector nHitMomentum= (*nHitsColl)[iHit]->GetMomentum();
//            // PrintEventStatistics(nHitPosition,nHitMomentum);
//            // Fill ntuple
//            fAnalysis->nFillNtuple(nHitPosition.x(), nHitPosition.y(), nHitPosition.z(),
//                                   nHitMomentum.x(), nHitMomentum.y(), nHitMomentum.z());
//        }
//    }



    // Output code of proton hits
    if(HCE)
    {
        if(pHitsCollID	!=	-1)	pHitsColl=(CollimatorDetectorHitsCollection*)(HCE->GetHC(pHitsCollID));
    }

    G4int	protonHits	=0	;
    // Store proton
    if(pHitsColl)
    {
        protonHits	=	pHitsColl->entries();
        G4cout << "Collimator Detectors have " << protonHits << " hits." << G4endl;
        if	(protonHits	>	0){

//            G4cout	<<	"Proton	Hit	#"	<<	"	"	<<	"   Position x,y,z	  "	<<		"	"
//                     <<	"   Momentum (x,y,z)	"<< G4endl	;
        }
        for(G4int	iHit=0;	iHit<protonHits;	iHit++){
             CollimatorDetectorHit* aHit = (*pHitsColl)[iHit];
//             aHit->Print();
             G4ThreeVector pHitPosition= (*pHitsColl)[iHit]->GetPosition();
             G4ThreeVector pHitMomentum= (*pHitsColl)[iHit]->GetMomentum();
//             PrintEventStatistics(pHitPosition,pHitMomentum);
             // Fill ntuple
             if(aHit->GetID()==0)
             {
            fAnalysis->gFillNtuple(pHitPosition.x(), pHitPosition.y(), pHitPosition.z(),
                                   pHitMomentum.x(), pHitMomentum.y(), pHitMomentum.z());}
             else
             {
            fAnalysis->nFillNtuple(pHitPosition.x(), pHitPosition.y(), pHitPosition.z(),
                                        pHitMomentum.x(), pHitMomentum.y(), pHitMomentum.z());
             }
        }
    }


}



//#include "EventAction.hh"
//#include "gammaSD.hh"
//#include "gammaHit.hh"
//#include "neutronHit.hh"
//#include "neutronSD.hh"
//#include "Analysis.hh"

//#include "G4RunManager.hh"
//#include "G4Event.hh"
//#include "G4SDManager.hh"
//#include "G4HCofThisEvent.hh"
//#include "G4UnitsTable.hh"

//#include "Randomize.hh"
//#include <iomanip>

////....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

//EventAction::EventAction()
// : G4UserEventAction(),
//   fPrintModulo(1)
//{ }

////....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

//EventAction::~EventAction()
//{}

////....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

//gammaHitsCollection*
//EventAction::GetHitsCollection(const G4String& hcName,
//                                  const G4Event* event) const
//{
//  G4int hcID
//    = G4SDManager::GetSDMpointer()->GetCollectionID(hcName);
//  gammaHitsCollection* hitsCollection
//    = static_cast<gammaHitsCollection*>(
//        event->GetHCofThisEvent()->GetHC(hcID));

//  if ( ! hitsCollection ) {
//    G4cerr << "Cannot access hitsCollection " << hcName << G4endl;
//    exit(1);
//  }

//  return hitsCollection;
//}

////....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

//void EventAction::PrintEventStatistics(G4ThreeVector Pos, G4ThreeVector Mom) const
//{
//  // print event statistics
//  G4cout
//     << "  Position : "
//     << std::setw(7) << G4BestUnit(Pos, "Length")
//     << "  Momentum: "
//     << std::setw(7) << G4BestUnit(Mom, "Energy")
//     << G4endl;
//}

////....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

//void EventAction::BeginOfEventAction(const G4Event* event)
//{

//  G4int eventID = event->GetEventID();
//  if ( eventID % fPrintModulo == 0 )  {
//    G4cout << "\n---> Begin of event: " << eventID << G4endl;
//  }
//}

////....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

//void EventAction::EndOfEventAction(const G4Event* event)
//{
//  // Get hits collections
//  gammaHitsCollection* HC
//    = GetHitsCollection("GAMMAHitsCollection", event);


//  // Get hit with total values
//  gammaHit* Hit = (*HC)[HC->entries()-1];


//  // Print per event (modulo n)
//  //
//  G4int eventID = event->GetEventID();
//  if ( eventID % fPrintModulo == 0) {
//    G4cout << "---> End of event: " << eventID << G4endl;

//    PrintEventStatistics(Hit->GetPosition(), Hit->GetMomentum());
//  }

//  // Fill ntuple
//  //

//  // get analysis manager
//  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();

//  // fill ntuple
//  analysisManager->FillNtupleDColumn(0, Hit->GetPosition().x());
//  analysisManager->FillNtupleDColumn(1, Hit->GetPosition().y());
//  analysisManager->FillNtupleDColumn(2, Hit->GetPosition().z());
//  analysisManager->FillNtupleDColumn(3, Hit->GetMomentum().x());
//  analysisManager->FillNtupleDColumn(4, Hit->GetMomentum().y());
//  analysisManager->FillNtupleDColumn(5, Hit->GetMomentum().z());
//  analysisManager->AddNtupleRow();
//}
