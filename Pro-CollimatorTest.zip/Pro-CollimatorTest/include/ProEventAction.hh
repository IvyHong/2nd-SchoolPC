#ifndef PROEVENTACTION_HH
#define PROEVENTACTION_HH

#include	"G4UserEventAction.hh"
#include	"G4ThreeVector.hh"
#include	"globals.hh"

class	ProRunAction;
class	G4HCofThisEvent;
class	ProAnalysis;

class	ProEventAction	:	public	G4UserEventAction
{
public:
                ProEventAction(ProRunAction*, ProAnalysis*);
                ~ProEventAction();

                void	BeginOfEventAction(const	G4Event*);
                void	   EndOfEventAction(const	G4Event*);

private:
                void PrintEventStatistics(G4ThreeVector Pos, G4ThreeVector Mom) const;

                //	data	members
                ProRunAction*			    fRunAct;
                ProAnalysis*              fAnalysis;
//                G4int       gHitsCollID,nHitsCollID;
                G4int                   pHitsCollID;
                G4int                  fPrintModulo;
};

#endif // PROEVENTACTION_HH
