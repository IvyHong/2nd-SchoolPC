#ifndef PRONEUTRONHIT_HH
#define PRONEUTRONHIT_HH

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"

/// ProNeutronhit class
///
/// It defines data members to store the the position and momentum
/// of Neutron in a selected volume:

class ProNeutronHit : public G4VHit
{
  public:
    ProNeutronHit(G4int i);
    ProNeutronHit(const ProNeutronHit&);
    virtual ~ProNeutronHit();

    // operators
    const ProNeutronHit& operator=(const ProNeutronHit&);
    G4int operator==(const ProNeutronHit&) const;

    inline void* operator new(size_t);
    inline void  operator delete(void*);

    // methods from base class
    virtual void Draw();
    virtual void Print();

    // methods to handle data
    void SetPosition(G4ThreeVector xyz) {nPosition=xyz;}
    void SetMomentum(G4ThreeVector XYZ) {nMomentum=XYZ;}

    // get methods
    inline G4int  GetID() const {return nID;}
    G4ThreeVector GetPosition() const;
    G4ThreeVector GetMomentum() const;

  private:
    G4int         nID;
    G4ThreeVector nPosition;        // particle position in the sensitive volume
    G4ThreeVector nMomentum;        // paticle momentum in the  sensitive volume

};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

typedef G4THitsCollection<ProNeutronHit> ProNeutronHitsCollection;

extern G4Allocator<ProNeutronHit> ProNeutronHitAllocator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

inline void* ProNeutronHit::operator new(size_t)
{
  void *hit;
  hit = (void *) ProNeutronHitAllocator.MallocSingle();
  return hit;
}

inline void ProNeutronHit::operator delete(void *hit)
{
  ProNeutronHitAllocator.FreeSingle((ProNeutronHit*) hit);
}


inline G4ThreeVector ProNeutronHit::GetPosition() const {
  return nPosition;
}

inline G4ThreeVector ProNeutronHit::GetMomentum() const {
  return nMomentum;
}

#endif // PRONEUTRONHIT_HH
