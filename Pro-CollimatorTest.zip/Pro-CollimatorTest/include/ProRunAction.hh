#ifndef PRORUNACTION_HH
#define PRORUNACTION_HH

#include	"G4UserRunAction.hh"
#include	"globals.hh"
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
class	ProAnalysis;
class	G4Run;

class	ProRunAction	:	public	G4UserRunAction
{
public:
            ProRunAction(ProAnalysis*);
            virtual ~ProRunAction();
public:
            void	BeginOfRunAction(const	G4Run*);
            void	  EndOfRunAction(const	G4Run*);

private:
            ProAnalysis*	   fanalysis;
};


#endif // PRORUNACTION_HH
