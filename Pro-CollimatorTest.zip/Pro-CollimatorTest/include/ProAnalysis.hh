#ifndef PROANALYSIS_HH
#define PROANALYSIS_HH

#include	"globals.hh"
#include	"g4csv.hh"      //g4csv can only used with ntuples

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

const	G4int	MaxNtCol	=	12;
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
class	ProAnalysis
{
public:
            ProAnalysis();
            ~ProAnalysis();

            void	book();
            void	save();
            void	gFillNtuple(G4double Pos_X, G4double Pos_Y, G4double Pos_Z,
                                G4double Mom_X, G4double Mom_Y, G4double Mom_Z);
            void	nFillNtuple(G4double Pos_X, G4double Pos_Y, G4double Pos_Z,
                                G4double Mom_X, G4double Mom_Y, G4double Mom_Z);

            void	PrintStatistic();

private:

            G4String            fileName[2];
            G4bool          	factoryOn;
            G4int               fNtColId[MaxNtCol];
};

#endif // PROANALYSIS_HH
