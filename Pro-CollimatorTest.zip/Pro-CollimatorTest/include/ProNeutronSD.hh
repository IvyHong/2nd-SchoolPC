#ifndef PRONEUTRONSD_HH
#define PRONEUTRONSD_HH

#include "G4VSensitiveDetector.hh"
#include "ProNeutronHit.hh"
#include <vector>

class G4Step;
class G4HCofThisEvent;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class ProNeutronSD : public G4VSensitiveDetector
{
  public:
      ProNeutronSD(const G4String& name);
      ~ProNeutronSD();

      void    Initialize(G4HCofThisEvent*);
      G4bool ProcessHits(G4Step*, G4TouchableHistory*);
      void    EndOfEvent(G4HCofThisEvent*);

  private:
      ProNeutronHitsCollection* nHitsCollection;
      G4int     nHCID;

};

#endif // PRONEUTRONSD_HH
