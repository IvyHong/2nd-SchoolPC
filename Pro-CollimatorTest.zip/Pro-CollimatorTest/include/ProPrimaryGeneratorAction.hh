#ifndef PROPRIMARYGENERATIONACTION_HH
#define PROPRIMARYGENERATIONACTION_HH

#include "G4VUserPrimaryGeneratorAction.hh"

#include "G4ParticleGun.hh"
#include "G4ThreeVector.hh"
#include "globals.hh"

class ProDetectorConstruction;
class G4ParticleGun;
class G4Event;

class ProPrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction
{
public:
    ProPrimaryGeneratorAction(ProDetectorConstruction* );
    virtual ~ProPrimaryGeneratorAction();

public:
   //method from the base class
    virtual void GeneratePrimaries(G4Event* );

private:

// Date member
    G4ParticleGun*        fParticleGun;
    ProDetectorConstruction* fDetector;
};

#endif // PROPRIMARYGENERATIONACTION_HH
